<?php
require_once(__DIR__ . '/vendor/autoload.php');
/**
  * Formats a line (passed as a fields  array) as CSV and returns the CSV as a string.
  * Adapted from http://us3.php.net/manual/en/function.fputcsv.php#87120
  */
function arrayToCsv( array &$fields, $delimiter = ';', $enclosure = '', $encloseAll = false, $nullToMysqlNull = false ) {
    $delimiter_esc = preg_quote($delimiter, '/');
    $enclosure_esc = preg_quote($enclosure, '/');

    $output = array();
    foreach ( $fields as $field ) {
        if ($field === null && $nullToMysqlNull) {
            $output[] = 'NULL';
            continue;
        }

        // Enclose fields containing $delimiter, $enclosure or whitespace
        if ( $encloseAll || preg_match( "/(?:${delimiter_esc}|${enclosure_esc}|\s)/", $field ) ) {
            $output[] = $enclosure . str_replace($enclosure, $enclosure . $enclosure, $field) . $enclosure;
        }
        else {
            $output[] = $field;
        }
    }

    return implode( $delimiter, $output );
}



$fp = fopen('file.csv', 'w');
// Configure OAuth2 access token for authorization: oauth2
SquareConnect\Configuration::getDefaultConfiguration()->setAccessToken('sq0atp-9ZJe1qVcF_9JvgONq2eNOg');


$api_instance = new SquareConnect\Api\TransactionsApi();
$location_id = "432CD4YSJ4PYT"; // string | The ID of the location to list refunds for.
$begin_time = "2018-05-01T00:00:00Z"; // string | The beginning of the requested reporting period, in RFC 3339 format.  See [Date ranges](#dateranges) for details on date inclusivity/exclusivity.  Default value: The current time minus one year.
$end_time = "2018-05-31T23:59:59Z"; // string | The end of the requested reporting period, in RFC 3339 format.  See [Date ranges](#dateranges) for details on date inclusivity/exclusivity.  Default value: The current time.
$sort_order = "DESC"; // string | The order in which results are listed in the response (`ASC` for oldest first, `DESC` for newest first).  Default value: `DESC`
$cursor = ""; // string | A pagination cursor returned by a previous call to this endpoint. Provide this to retrieve the next set of results for your original query.  See [Paginating results](#paginatingresults) for more information.

try {

	$cursorPresent = true; 
	$rowNumber = 1;
    fwrite($fp, "id, location_id, createdAt, transaction_id, tender_id, created_at, reason, refunded_amount, refunded_currency, refunded_processing_amount, refunded_processing_currency, status, weblincId\n");
	while($cursorPresent)
	{
	    $resultList = $api_instance->listRefunds($location_id, $begin_time, $end_time, $sort_order, $cursor);

	    foreach($resultList["refunds"] as $lineItem )
	    {
	    	print_r($rowNumber + "\n"); 
	    	$rowNumber++;
	    	$retrieveTransactionResponse = $api_instance->retrieveTransaction($location_id, $lineItem["transaction_id"]);
	    	$weblincId = $retrieveTransactionResponse["transaction"]["tenders"][0]["note"];
	    	fwrite($fp, "{$lineItem["id"]}, {$lineItem["created_at"]}, {$lineItem["location_id"]}, {$lineItem["transaction_id"]}, {$lineItem["tender_id"]}, {$lineItem["created_at"]}, {$lineItem["reason"]}, {$lineItem["amount_money"]["amount"]}, {$lineItem["amount_money"]["currency"]}, {$lineItem["processing_fee_money"]["amount"]}, {$lineItem["processing_fee_money"]["currency"]}, {$lineItem["status"]}, {{$weblincId}}\n");
	    }
	    $cursor = $resultList["cursor"];

	    if($resultList["cursor"] == '')
	    {
	    	$cursorPresent = false;
	    	print_r("I should have quit!!");
	    }
	}

fclose($fp);
} catch (Exception $e) {
    echo 'Exception when calling TransactionsApi->listRefunds: ', $e->getMessage(), PHP_EOL;
}
?>

